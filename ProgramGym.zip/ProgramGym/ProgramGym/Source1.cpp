//Skye Hewitt
//sbhngh@mail.umkc.edu
//3-31-2019
//CS 201
//Program 4 - Gym Item Check Out

#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

class Students {
private:
	//Variables
	string firstName, lastName;
	int unsigned IDNumber, itemsOut, defaultNum;
	string* itemsCheckedOut;

public:
	//Default constructor
	Students();
	//Getters
	int GetID() { return IDNumber; }
	string GetFirtstName() { return firstName; }
	string GetLastName() { return lastName; }
	int CheckoutCount() { return itemsOut; }
	//Setters
	void SetIDNumber(int IDNumber) { this->IDNumber = IDNumber; }
	void SetFirstName(string firstName) { this->firstName = firstName; }
	void SetLastName(string lastName) { this->lastName = lastName; }
	//Other functions
	bool CheckOut(const string& item);
	bool CheckIn(const string& item);
	bool HasCheckedOut(const string& item);
	void Clear();
	friend ostream& operator<<(ostream& out, const Students& item);
	//Destructor
	~Students();
};

Students::Students() {
	//Default constructor
	firstName = "";
	lastName = "";
	IDNumber = 0;
	itemsOut = 0;
}

bool Students::CheckOut(const string& item) {
	/*If there are no items checked out/no array of items checked out, a new dynamic array
	is created and initialized with "0"'s.*/
	if (itemsOut == 0) {
		itemsCheckedOut = new string[defaultNum];
		for (int i = 0; i < defaultNum; ++i) {
			itemsCheckedOut[i] = "0";
		}
	}
	//If the item is already checked out, it cannot be checked out
	if (HasCheckedOut(item)) {
		return false;
	}
	//If the item is not checked out, it is added to the item array and the itemsOut is incremented
	for (int i = 0; i < defaultNum; ++i) {
		if (itemsCheckedOut[i] == "0") {
			itemsCheckedOut[i] = item;
			++itemsOut;
			return true;
		}
	}
}

bool Students::CheckIn(const string& item) {
	for (int i = 0; i < itemsOut; ++i) {
		//If the item is checked out, it is taken out and the number of itemsOut is decremented
		if (itemsCheckedOut[i] == item) {
			itemsCheckedOut[i] = "0";
			--itemsOut;
			return true;
		}
	}
	//If it is not checked out, returns false
	return false;
}



bool Students::HasCheckedOut(const string& item) {
	//If the item is checked out returns true, otherwise false
	for (int i = 0; i < itemsOut; ++i) {
		if (itemsCheckedOut[i] == item) {
			return true;
		}
	}
	return false;
}

void Students::Clear() {
	//Returns all to initial conditions
	firstName = "";
	lastName = "";
	IDNumber = 0;
	itemsOut = 0;
	delete[]itemsCheckedOut;
	itemsCheckedOut = NULL;
}

Students::~Students() {
	//Deletes the dynamic array list for the items checked out
	delete[]itemsCheckedOut;
	itemsCheckedOut = NULL;
}

ostream& operator<<(ostream& out, const Students& item) {
	for (int i = 0; i < item.defaultNum; ++i) {
		if (item.itemsCheckedOut[i] != "0") {
			out << item.itemsCheckedOut[i] << endl;
		}
	}
	return out;
}

int main() {
	ifstream inStudents("Students.txt");
	ifstream inCheckins("checkins.txt");
	ifstream inCheckouts("checkouts.txt");
	ofstream outStudents("UPDATEDStudents.txt");
	vector<int> IDCheckouts;
	vector<string> itemCheckouts;
	vector<string> itemCheckins;
	Students newStudent;
	int newIDNumber, newItemsOut;
	string newFirstName, newLastName, newItem;

	//checkouts.txt
	while (!inCheckouts.eof()) {
		//Creating lists of IDs with corresponding item that they checked out to be checked against later
		//Using a vector as items will be removed from it
		inCheckouts >> newIDNumber;
		inCheckouts >> newItem;
		IDCheckouts.push_back(newIDNumber);
		itemCheckouts.push_back(newItem);

	}

	//Header
	outStudents << left << setw(6) << "ID" << setw(9) << "FIRST" << "LAST" << endl << "--------------------------------------------------" << endl;

	//Students.txt
	while (!inStudents.eof()) {
		//Initializing newStudent 
		newStudent.Clear();
		inStudents >> newIDNumber >> newFirstName >> newLastName >> newItemsOut;
		newStudent.SetIDNumber(newIDNumber);
		newStudent.SetFirstName(newFirstName);
		newStudent.SetLastName(newLastName);

		//Names and ID numbers
		outStudents << setw(6) << newStudent.GetID() << setw(9) << newStudent.GetFirtstName() << newStudent.GetLastName() << endl;

		outStudents << "Items Checked Out : ";

		//Checking out the items that the students initially checked out
		for (int i = 0; i < newItemsOut; ++i) {
			inStudents >> newItem;
			newStudent.CheckOut(newItem);
		}

		//Checking out items that the students checked out during their visit
		for (int i = 0; i < IDCheckouts.size(); ++i) {
			if (IDCheckouts.at(i) == newStudent.GetID() && newStudent.CheckOut(itemCheckouts.at(i))) {
				IDCheckouts.erase(IDCheckouts.begin() + i);
				itemCheckouts.erase(itemCheckouts.begin() + i);
			}
		}

		//Checking in items that students checked in during their visit
		//The items checked in will be returned from the first students that visited
		for (int i = 0; i < itemCheckins.size(); ++i) {
			if (newStudent.CheckIn(itemCheckins.at(i))) {
				itemCheckins.erase(itemCheckins.begin() + i);
			}
		}
		//If after checking all checkins and checkouts, they have 0 items checked out
		if (newItemsOut == 0) {
			outStudents << "NONE" << endl;
		}
		//Outputting what is left in the array
		outStudents << newStudent << endl;

		//Set all to defaults
		newStudent.Clear();

	}
}